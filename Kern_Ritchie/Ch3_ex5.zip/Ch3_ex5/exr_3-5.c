/*
 * main.c
 *
 *  Created on: 08-Jan-2018
 *      Author: saum
 *  Description: Write the function itob(n,s,b) that converts the integer n into a base b
				character representation in the string s . In particular, itob(n,s,16) formats s as a
				hexadecimal integer in s .
 */

#include <stdio.h>
#include <string.h>

/* reverse: reverse string s in place */
void reverse(char s[])
{
	int c, i, j;
	for (i = 0, j = strlen(s)-1; i < j; i++, j--) {
		c = s[i];
		s[i] = s[j];
		s[j] = c;
	}
}

//Conv Integer to String with the given base
void itoa(int n, char s[], int base)
{
	int i, rem;

	i = 0;
	switch (base){
	case 2:
		do {
			/* generate digits in reverse order in Binary */
			s[i++] = n % 2 + '0'; /* get next digit */
		} while ((n /= 2) > 0);
		break;
	case 16:
		do {
			/* generate digits in reverse order in Hexa decimal */
			rem = n % 16;
			if(rem < 10)
				s[i++] = rem + '0'; /*  */
			else
				s[i++] = (rem - 10) + 'A'; /*  */
		} while ((n /= 16) > 0);
		break;
	default:
		printf("Invalid base input");
	}

	s[i] = '\0';
	reverse(s);
}

int main()
{
	char str[100];
	int num, base;
	base = 16, num = 255;
	itoa(num, str, base);
	printf("Integer %d converted into a base %d : %s", num, base, str);

	return 1;
}
