This program contains Exr 4-3 from Kern_Ritchie completely solved with make file used to build the executable.
This projects needs to be compiled with -lm option due to using math.h lib

The problem is to write a calculator program
	that provides the operators + , - , * and / .
	In reverse Polish notation, each operator follows its operands;
	an infix expression like (1 - 2) * (4 + 5) is entered as
	1 2 - 4 5 + * (Ans = -9)
	Parentheses are not needed; the notation is unambiguous as long as we know how many
	operands each operator expects.

Add the modulus (%) operator and provisions for negative numbers.
1 -2 - 4 5 + * (Ans = 27)

Exercise 4-4. Add the commands to print the top elements of the stack without popping, to
	duplicate it, and to swap the top two elements. Add a command to clear the stack.