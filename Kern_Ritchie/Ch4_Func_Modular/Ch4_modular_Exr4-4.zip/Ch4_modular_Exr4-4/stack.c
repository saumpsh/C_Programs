/*
 * stack.c
 *
 *  Created on: 13-Dec-2017
 *      Author: saum
 *      Desc  : This file is used to perform the operation of
 *      push and pop variable to and from the memory.
 */

//user-defined header file
#include "calc.h"
#include <ctype.h>

#define MAXVAL 100 /* maximum depth of val stack */
int sp = 0;	/* next free stack position */
double val[MAXVAL]; /* value stack */
//Func prototype
void get_top_position(void);

/* push: push f onto value stack */
void push(double f)
{
	if (sp < MAXVAL)
		val[sp++] = f;
	else
		printf("error: stack full, can't push %g\n", f);
}

/* pop: pop and return top value from stack */
double pop(void)
{
	if (sp > 0)
		return val[--sp];
	else {
		printf("error: stack empty\n");
		return 0.0;
	}
}

//clear the stack
void clear_stack(void)
{
	sp = 0;
}

void prt_top_elmnt(void)
{
	get_top_position();
	double first = val[--sp], second = val[--sp];
	printf("The top 2 elements are: %.2f and %.2f", first, second);

}

void swap_elements()
{
	get_top_position();
	double a = pop(), b = pop();
	push(a); push(b);
}

void duplicate_elements()
{
	get_top_position();
	double element=pop();
	push(element); push(element);
}

void get_top_position(void)
{
	int st_ptr_top = 0, i;
	for(i=0; val[i] != 0; ++i)
	{
		st_ptr_top++;
	}
	sp=st_ptr_top;
}
