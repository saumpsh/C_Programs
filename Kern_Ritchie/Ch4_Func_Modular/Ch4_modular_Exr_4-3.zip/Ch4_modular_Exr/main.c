/*
 * sample_3.c
 *
 *  Created on: 12-Dec-2017
 *      Author: saum
 *  The problem is to write a calculator program
	that provides the operators + , - , * and / .
	In reverse Polish notation, each operator follows its operands;
	an infix expression like (1 - 2) * (4 + 5) is entered as
	1 2 - 4 5 + * (Ans = -9)
	Parentheses are not needed; the notation is unambiguous as long as we know how many
	operands each operator expects.
	Added the modulus (%) operator and provisions for negative numbers.
 */

#include <stdlib.h> 	/* for atof() */
//user-defined header file
#include "calc.h"
#include "math.h"

#define MAXOP 100		/* max size of operand or operator */

/* reverse Polish calculator */
int main()
{
	int type;
	double op2;
	char s[MAXOP];
	while ((type = getop(s)) != EOF) {
		switch (type) {
		case NUMBER:
			push(atof(s));
			break;
		case '+':
			push(pop() + pop());
			break;
		case '*':
			push(pop() * pop());
			break;
		case '-':
			op2 = pop();
			push(pop() - op2);
			break;
		case '/':
			op2 = pop();
			if (op2 != 0.0)
				push(pop() / op2);
			else
				printf("error: zero divisor\n");
			break;
		case '%':
			op2 = pop();
			double op1 = pop();
			if(op2 != 0.0)
				//The C library function double fmod(double x, double y)
				//returns the remainder of x divided by y
				push(fmod(op1, op2));
			else
				printf("error: zero divisor\n");
			break;
		case '\n':
			printf("\t%.8g\n", pop());
			break;
		default:
			printf("error: unknown command %s\n", s);
			break;
		}
	}
	return 0;
}
