/*
 * getchar_2.c
 *
 *  Created on: 23-Dec-2017
 *      Author: saum
 *
 */

#define BUFSIZE 100
char buf[BUFSIZE];
int bufp = 0;	/* buffer for ungetch */
#include "int_conv.h"

/* next free position in buf */
int getch(void) /* get a (possibly pushed-back) character */
{
	return (bufp > 0) ? buf[--bufp] : getchar();
}

void ungetch(int c)
/* push character back on input */
{
	if (bufp >= BUFSIZE)
		printf("ungetch: too many characters\n");
	else
		buf[bufp++] = (char) c;
}

