/*
 * int_conv.h
 *
 *  Created on: 22-Dec-2017
 *      Author: saum
 */

#ifndef INT_CONV_H_
#define INT_CONV_H_

#include <ctype.h>
int getch(void);
void ungetch(int);
int getint(int *);
#include <stdio.h>

#endif /* INT_CONV_H_ */
