/*
 * main.c
 *
 *  Created on: 23-Dec-2017
 *      Author: saum
 *Description : consider a function getint that performs free-format input conversion by
				breaking a stream of characters into integer values, one integer per call.
				getint has to return the value it found and also signal end of file when there is no more input.
 *
 */


#define SIZE 5
#include "int_conv.h"

void main()
{
    int n, array[SIZE], i, status;
    n = 0;
    //Initialize all array elements to 0
    for(i=0; i < (sizeof(array)/sizeof(array[0])); i++)
    	array[i]= 0;

    /*What it does: it reopens stdin file descriptor and attaches input.txt to it.
    It attaches it for reading - second argument is "r"*/
    freopen("inp_file.txt", "r", stdin);

    /*for (n = 0; n < SIZE && (getint(&array[n]) != EOF); n++)
        ;*/
    while (n < SIZE)
    {
    	status = getint(&array[n]);
    	if(array[n] == 0)
    		n--;
    	if( status == EOF) // || status == '\n')
    		break;
    	else
    		n++;
    }
    printf("The input is:");
    for(i=0; i < (sizeof(array)/sizeof(array[0])); i++)
    	printf("%d\n\t", array[i]);
}
