/*
 * int_conv.h
 *
 *  Created on: 22-Dec-2017
 *      Author: saum
 */

#ifndef INT_CONV_H_
#define INT_CONV_H_

void xstrcat ( char *t, char *s );
int xstrend(char *s, char *t);
#include <stdio.h>

#endif /* INT_CONV_H_ */
