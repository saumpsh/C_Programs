/* Program to perform some basic operations on string. 
Kernighan Ritchie  Ch5 Exer 5.3, 5.4, 5.5

*/

#include "str_fns.h"

void main( )
{
	char s1[20] = "Saumil" ;
	char s2[ ] = "Shah" ;
	char s3[] = "Kaushil";

	printf ( "String s1: %s\n", s1 ) ;
	printf ( "String s2: %s\n", s2 ) ;

	xstrcat ( s1, s2 ) ;
	printf ( "String s1 after concatenation: %s\n", s1 ) ;

	if(xstrend(s1,s3))
		printf ( "String s1 occurs at end of String s2\n" ) ;
	else
		printf ( "String s1 does NOT occurs at end of String s2\n" ) ;

}


