/*
 * str_fns.c
 *
 *  Created on: 28-Dec-2017
 *      Author: saum
 */

#include "str_fns.h"

/* concatenates the two strings */
void xstrcat ( char *t, char *s )
{
	/*int i, j;
	i = j = 0;
	while (t[i] != '\0')
		i++;
	while ((t[i] = s[j]) != '\0')
	{
		i++; j++;
	}*/
	while (*t != '\0')  //find end of t
	{
		t++;
	}		
	while ((*t = *s) != '\0')  //copy s
	{
		t++; s++;			
	}
}

/*returns 1 if the string t occurs at the
end of the string s , and zero otherwise.*/
int xstrend(char *s, char *t)
{
	int no_t = 0;  //count no of elements in t
	while (*s != '\0')  //find end of s
		s++;
	while (*t != '\0')  //find end of t
		t++; no_t++;
	s = --s - no_t; //s points to nth element = no of
					//element of t.... counting from behind
	t = --t - no_t;	//t points to starting element

	while (*s == *t)  //compare end string of s with that of t
		t++; s++;
	t--;
	if(*t == '\0')	//If t increments till end end of s matches t
		return 1;
	else
		return 0;
}
