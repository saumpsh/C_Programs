/*
 * alloc.h
 *
 *  Created on: 30-Dec-2017
 *      Author: saum
 */

#ifndef ALLOC_H_
#define ALLOC_H_

char *alloc(int);

#endif /* ALLOC_H_ */
