/*
 * line_opr.h
 *
 *  Created on: 30-Dec-2017
 *      Author: saum
 */

#ifndef LINE_OPR_H_
#define LINE_OPR_H_

//Function prototype
int readlines(char *lineptr[], int nlines);
void writelines(char *lineptr[], int nlines);
#include <stdio.h>

#endif /* LINE_OPR_H_ */
