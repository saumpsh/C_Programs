/*
 * sort.h
 *
 *  Created on: 30-Dec-2017
 *      Author: saum
 */

#ifndef SORT_H_
#define SORT_H_

void qsort(char *lineptr[], int left, int right);

#endif /* SORT_H_ */
