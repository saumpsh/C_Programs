/*
 * main.c
 *
 *  Created on: 30-Dec-2017
 *      Author: saum
 * description:writing a program that will sort a set of text lines into alphabetic
				order
 */


#include "sort.h"
#include "line_opr.h"

#define MAXLINES 5000 /* max #lines to be sorted */
char *lineptr[MAXLINES]; /* pointers to text lines */

/* sort input lines */
int main()
{
	int nlines; 	/* number of input lines read */

	/*What it does: it reopens stdin file descriptor and attaches input.txt to it.
	It attaches it for reading - second argument is "r"*/
	freopen("inp_file.txt", "r", stdin);

	if ((nlines = readlines(lineptr, MAXLINES)) >= 0) {
		qsort(lineptr, 0, nlines-1);
		writelines(lineptr, nlines);
		return 0;
	} else {
		printf("error: input too big to sort\n");
		return 1;
	}
}
