/*
 * main.c
 *
 *  Created on: 01-Jan-2018
 *      Author: saum
 *  Description:If we choose -x (for ``except'') to signal the inversion,
 *  		and -n (``number'') to request line numbering, then the command
			find -x -npattern will print each line
			that doesn't match the pattern, preceded by its line number.
	execute command : ./app -x -n Saumil
 */

#include <stdio.h>
//int xgetline(char *line, int max);
#include <string.h>

#define MAXLINE 1000

/* find: print lines that match pattern from 1st arg */
main(int argc, char *argv[])
{

	freopen("inp_file.txt", "r", stdin);
	char line[MAXLINE];
	long lineno = 0;
	int c, except = 0, number = 0, found = 0;
	/**++argv is a pointer to an argument string,
	so (*++argv)[0] is its first character.*/
	while (--argc > 0 && (*++argv)[0] == '-')
		/*the task is to walk along a specific argument string.
		 * In the inner loop, the expression *++argv[0] increments the pointer argv[0] */
		while (c = *++argv[0])
			switch (c) {
			case 'x':
				except = 1;
				break;
			case 'n':
				number = 1;
				break;
			default:
				printf("find: illegal option %c\n", c);
				argc = 0;
				found = -1;
				break;
			}
	if (argc != 1)
		printf("Usage: find -x -n pattern\n");
	else
		while (xgetline(line, MAXLINE) > 0) {
			lineno++;
			//If pattern is found, the "if (true != except = 1)" = false and nothing is printed.
			//If pattern not is found, the "if (false != except = 1)" = true and line is printed.
			if ((strstr(line, *argv) != NULL) != except) {
				if (number)
					printf("%ld:", lineno);
				printf("%s", line);
				found++;
			}
		}
	return found;
}

int xgetline(char s[], int lim)
{
    int c,i;

    for(i=0; i<lim-1 && (c=getchar())!=EOF && c!='\n'; ++i)
        s[i] = c;
    if(c== '\n'){
        s[i] = c;
        ++i;
    }
    s[i] = '\0';
    return i;
}


