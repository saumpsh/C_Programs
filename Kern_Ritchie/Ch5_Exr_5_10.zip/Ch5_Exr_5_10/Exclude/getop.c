/*
 * getop.c
 *
 *  Created on: 13-Dec-2017
 *      Author: saum
 */

/*#include <ctype.h>
//user-defined header file
#include "calc.h"

int getch(void);
void ungetch(int);

 getop: get next character or numeric operand
int getop(char s[])
{
	int i, c;
	c = s[0];

	 check for a negative  number
	i = 0;
	if (c == '-' )
	{
		if (isdigit(c = s[++i]))
		{
			while (isdigit(s[++i] = c ))
				;
		}
		else
			return '-';
	}

	//Is an operator
	if (!isdigit(c) && c != '.' && c != ' ')
		return c;

	if (isdigit(c)) 	 collect integer part
		while (isdigit(c = s[++i]))
			;
	if (c == '.') 		 collect fraction part
		while (isdigit(s[++i] = c))
			;
	return NUMBER;
}*/
