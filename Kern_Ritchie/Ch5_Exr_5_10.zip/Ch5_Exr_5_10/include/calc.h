/*
 * calc.h
 *
 *  Created on: 13-Dec-2017
 *      Author: saum
 */

#ifndef CALC_H_
#define CALC_H_

#include <stdio.h>
#define NUMBER '0'		/* signal that a number was found */
void push(double);
double pop(void);
//int getop(char *);


#endif /* CALC_H_ */
