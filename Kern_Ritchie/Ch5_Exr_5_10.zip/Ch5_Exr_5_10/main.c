/*
 * sample_3.c
 *
 *  Created on: 12-Dec-2017
 *      Author: saum
 *  Description:Write the program expr , which evaluates a reverse Polish expression from the
				command line, where each operator or operand is a separate argument. For example,
				expr 2 3 4 + *
				evaluates 2 * (3+4). = 14
 */

#include <stdlib.h> 	/* for atof() */
#include <ctype.h>
#include <string.h>
//user-defined header file
#include "calc.h"

#define MAXOP 100		/* max size of operand or operator */

/* reverse Polish calculator */
int main(int argc, char *argv[])
{
	int type, c;
	double op2;
	while (--argc > 0) {
		c = **++argv;
		if (isdigit(c))
			type = NUMBER;
		else
			type = c;
		switch (type) {
		case NUMBER:
			push(atof(*argv));
			break;
		case '+':
			push(pop() + pop());
			break;
		case 'p':
			push(pop() * pop());
			break;
		case '-':
			op2 = pop();
			push(pop() - op2);
			break;
		case '/':
			op2 = pop();
			if (op2 != 0.0)
				push(pop() / op2);
			else
				printf("error: zero divisor\n");
			break;
		default:
			printf("error: unknown command %x\n", **argv);
			break;
		break;
		}

	}
	if (argc != 0)
		printf("Usage: expr 2 3 4 + *\n");
	else
		printf("\t%.8g\n", pop());
	return 0;
}
