/* Exercise 1-1: Hello World
 *
 * "Run the "hello, world" program on your system. Experiment with leaving out
 *  parts of the program, to see what error messages you get."
 */

// Includes

#include <stdio.h>

/* Main */

int main(void) {

    printf("Hello world!\n");

    return 0;
}
