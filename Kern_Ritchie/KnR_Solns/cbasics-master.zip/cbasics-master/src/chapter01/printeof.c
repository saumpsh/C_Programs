/* Exercise 1-7: Print the value of EOF
 *
 * Write a program to print the value of EOF
 */

// Includes

#include <stdio.h>

/* Main */

int main(void) {

    printf("The value of EOF is '%d'\n", EOF);

    return 0;
}
