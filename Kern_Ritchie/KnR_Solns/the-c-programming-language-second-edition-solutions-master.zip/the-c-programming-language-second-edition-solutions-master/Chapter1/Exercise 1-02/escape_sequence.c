/**
 * Author: Jeremy Yu <ccpalettes@gmail.com>
 * 
 * Solution for Exercise 1-2, Chapter1.
 */

#include <stdio.h>

int main(void)
{
    printf("tab: \t\n");
    printf("backslash: \\\n");
    printf("single quote: \'\n");
    printf("double quote: \"\n");
    return 0;
}