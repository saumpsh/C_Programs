/**
 * Author: Jeremy Yu <ccpalettes@gmail.com>
 * 
 * Solution for Exercise 5-07, Chapter5.
 */

void qsort(char *lineptr[], int left, int right);