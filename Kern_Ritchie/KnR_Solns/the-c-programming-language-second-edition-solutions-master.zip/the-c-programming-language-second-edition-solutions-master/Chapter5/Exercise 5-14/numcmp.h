/**
 * Author: Jeremy Yu <ccpalettes@gmail.com>
 * 
 * Solution for Exercise 5-14, Chapter5.
 */

int numcmp(char *, char *);