/**
 * Author: Jeremy Yu <ccpalettes@gmail.com>
 * 
 * Solution for Exercise 5-15, Chapter5.
 */

void qsort(void *lineptr[], int left, int right, int (*comp)(void *, void *), int order);