the-c-programming-language-second-edition-solutions
===================================================

Solutions for all exercises in the book "The C Programming Language - Second Edition"(referred to as K&amp;R, after its authors' initials) by Brian W. Kernighan and Dennis M. Ritchie.