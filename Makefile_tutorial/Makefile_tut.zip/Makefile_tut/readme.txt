'make' command to build app target and move the target to bin directory
'make cleanall' to delete all object and targets.

This make file builds the executable target by compiling source files 
and linking the object file.

3 sub-directories:

    include - where all .h files are.
    obj - directory where all object files are moved after
          build and from where they are moved before starting a new build.
    bin - where final executables are copied. The object 
          files are automatically moved to obj directory after compilation

https://www.codeproject.com/Articles/31488/Makefiles-in-Linux-An-Overview#T7

