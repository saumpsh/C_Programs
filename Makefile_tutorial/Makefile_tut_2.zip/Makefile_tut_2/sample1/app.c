#include <stdio.h>
#include <stdlib.h>
#include "inc_a.h"

int main (int arg, char *argv[])
{
	printf( "\nHello World!\n" );

	return 0;
}
