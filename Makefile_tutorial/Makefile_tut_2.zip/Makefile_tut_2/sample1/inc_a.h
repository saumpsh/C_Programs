#ifndef _INC_A_

#define _INC_A_

#define SOME_VALUE 1

#endif

