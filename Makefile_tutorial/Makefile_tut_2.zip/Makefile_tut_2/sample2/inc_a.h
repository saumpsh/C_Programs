#ifndef _INC_A_

#define _INC_A_

void func_a(void);

#endif

