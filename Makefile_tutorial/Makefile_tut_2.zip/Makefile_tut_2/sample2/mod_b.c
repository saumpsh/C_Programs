#include <stdio.h>
#include <stdlib.h> 
#include "inc_b.h"
 
void func_b(void)
{
	printf( "\nHello, I m func_b!\n" );
}
