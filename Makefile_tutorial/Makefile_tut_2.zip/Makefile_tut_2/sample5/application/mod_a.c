#include <stdio.h>
#include <stdlib.h> 
#include <inc_a.h>
#include <tstlib.h>
 
void func_a(void)
{
	printf( "\nHello, I m func_a!\n" );
	tlib_hello_func_a();
}
