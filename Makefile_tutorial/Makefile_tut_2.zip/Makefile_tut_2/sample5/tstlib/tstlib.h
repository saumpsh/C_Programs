#ifndef _TST_LIB_INCLUDED_

#define _TST_LIB_INCLUDED_

void tlib_hello_func_a(void);
void tlib_hello_func_b(void);

#endif
