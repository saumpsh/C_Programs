#include <stdio.h>
#include <stdlib.h>
#include <tstlib.h> 

void tlib_hello_func_b(void)
{
	printf( "\nHello, I m tlib_hello_func_b from tstlib.a!\n" );
}

